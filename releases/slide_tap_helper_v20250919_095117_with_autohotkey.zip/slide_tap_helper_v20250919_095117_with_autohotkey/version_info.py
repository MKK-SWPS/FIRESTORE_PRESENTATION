VERSION_INFO = {
    'version': '2025.09.19.d432a63',
    'build_date': '2025.09.19',
    'commit': 'd432a63',
    'branch': 'local'
}